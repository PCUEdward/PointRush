import javax.swing.*;
import java.awt.*;

public class GameClient {
    private JFrame frame;

    public GameClient() {
        frame = new JFrame("POINT RUSH");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(360, 640);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.add(new StartPanel(frame));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GameClient::new);
    }

    class StartPanel extends JPanel {
        public StartPanel(JFrame topFrame) {
            setLayout(new BorderLayout());
            JButton playButton = new JButton("PLAY");
            playButton.setPreferredSize(new Dimension(50, 20));
            playButton.setSize(50, 20);;
            playButton.addActionListener(e -> {
                topFrame.getContentPane().removeAll();
                topFrame.add(new LoginPanel(topFrame));
                topFrame.revalidate();
                topFrame.repaint();
            });

            add(playButton, BorderLayout.CENTER);
        }
    }
}
