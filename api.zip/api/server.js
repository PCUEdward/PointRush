const http = require('http');
const mysql = require('mysql');
const bcrypt = require('bcryptjs');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'game_db',
  port: 3400 // Ensure this matches your MySQL server port
});

connection.connect((err) => {
  if (err) {
    console.error('Connection failed: ', err);
    return;
  }
  console.log('Connected to database');
});

const server = http.createServer((req, res) => {
  let body = '';

  req.on('data', (chunk) => {
    body += chunk.toString();
  });

  req.on('end', () => {
    if (req.method === 'POST' && req.url === '/signup') {
      const data = JSON.parse(body);
      const username = data.username;
      const password = bcrypt.hashSync(data.password, 10);

      connection.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], (err) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
        } else {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        }
      });
    } else if (req.method === 'POST' && req.url === '/login') {
      const data = JSON.parse(body);
      const username = data.username;
      const password = data.password;

      connection.query('SELECT id, password FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
          return;
        }

        if (results.length > 0) {
          const user = results[0];
          if (bcrypt.compareSync(password, user.password)) {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, user_id: user.id, message: 'Login Successful' }));
          } else {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: false, error: 'Invalid password' }));
          }
        } else {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: 'User not found' }));
        }
      });
    } else if (req.method === 'POST' && req.url === '/delete_account') {
      const data = JSON.parse(body);
      const username = data.username;
      const password = data.password;

      connection.query('SELECT id, password FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
          return;
        }

        if (results.length > 0) {
          const user = results[0];
          if (bcrypt.compareSync(password, user.password)) {
            connection.query('DELETE FROM users WHERE id = ?', [user.id], (err) => {
              if (err) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false, error: err.message }));
              } else {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true }));
              }
            });
          } else {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: false, error: 'Invalid password' }));
          }
        } else {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: 'User not found' }));
        }
      });
    } else if (req.method === 'POST' && req.url === '/score') {
      const data = JSON.parse(body);
      const username = data.username;
      const score = data.score;

      connection.query('UPDATE users SET score = ? WHERE username = ?', [score, username], (err) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
        } else {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        }
      });
    } else if (req.method === 'GET' && req.url.startsWith('/highscore')) {
      const urlParams = new URLSearchParams(req.url.split('?')[1]);
      const username = urlParams.get('username');

      connection.query('SELECT score FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
          return;
        }

        if (results.length > 0) {
          const user = results[0];
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, score: user.score }));
        } else {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: 'User not found' }));
        }
      });
    } else if (req.method === 'POST' && req.url === '/update_highscore') {
      const data = JSON.parse(body);
      const username = data.username;
      const score = data.score;
    
      connection.query('UPDATE users SET highscore = ? WHERE username = ? AND (highscore < ? OR highscore IS NULL)', [score, username, score], (err) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
        } else {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        }
      });
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not found' }));
    }
  });
});

const port = process.env.PORT || 3000; // This is the port your Node.js server listens on
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
