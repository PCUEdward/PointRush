import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class GameClient extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private int userId;

    public GameClient() {
        setTitle("Point Chasing Game");
        setSize(1080, 1920);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        showInitialScreen();
    }

    private void showInitialScreen() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JButton playButton = new JButton("PLAY");
        playButton.setPreferredSize(new Dimension(100, 50));
        playButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showLoginScreen();
            }
        });

        panel.add(playButton, gbc);

        setContentPane(panel);
        revalidate();
        repaint();
    }

    private void showLoginScreen() {
        JPanel panel = new JPanel(new GridLayout(5, 2));

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
        panel.add(loginButton);

        JButton signupButton = new JButton("Sign Up");
        signupButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                signUp();
            }
        });
        panel.add(signupButton);

        JButton deleteAccountButton = new JButton("Delete Account");
        deleteAccountButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteAccount();
            }
        });
        panel.add(deleteAccountButton);

        setContentPane(panel);
        revalidate();
        repaint();
    }

    private void login() {
        try {
            URL url = new URL("http://localhost/api/login.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setDoOutput(true);

            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String jsonInputString = "{\"username\": \"" + username + "\", \"password\": \"" + password + "\"}";

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }

                String responseString = response.toString();
                if (responseString.contains("\"success\":true")) {
                    userId = Integer.parseInt(responseString.split("\"user_id\":")[1].split(",")[0]);
                    JOptionPane.showMessageDialog(this, "Login Successful");
                    showGameScreen(); // Directly show the game screen
                } else {
                    String error = responseString.split("\"error\":\"")[1].split("\"")[0];
                    JOptionPane.showMessageDialog(this, "Login Failed: " + error);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void signUp() {
        try {
            URL url = new URL("http://localhost/api/signup.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setDoOutput(true);

            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String jsonInputString = "{\"username\": \"" + username + "\", \"password\": \"" + password + "\"}";

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }

                String responseString = response.toString();
                if (responseString.contains("\"success\":true")) {
                    JOptionPane.showMessageDialog(this, "Signup Successful");
                } else {
                    String error = responseString.split("\"error\":\"")[1].split("\"")[0];
                    JOptionPane.showMessageDialog(this, "Signup Failed: " + error);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void deleteAccount() {
        try {
            URL url = new URL("http://localhost/api/delete_account.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setDoOutput(true);

            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String jsonInputString = "{\"username\": \"" + username + "\", \"password\": \"" + password + "\"}";

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }

                String responseString = response.toString();
                if (responseString.contains("\"success\":true")) {
                    JOptionPane.showMessageDialog(this, "Account Deleted Successfully");
                } else {
                    String error = responseString.split("\"error\":\"")[1].split("\"")[0];
                    JOptionPane.showMessageDialog(this, "Account Deletion Failed: " + error);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showGameScreen() {
        GamePanel gamePanel = new GamePanel();
        setContentPane(gamePanel);
        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new GameClient().setVisible(true);
            }
        });
    }
}
