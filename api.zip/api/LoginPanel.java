import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginPanel extends JPanel {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton signupButton;
    private JButton deleteAccountButton;
    private JLabel messageLabel;
    private JFrame topFrame;

    public LoginPanel(JFrame topFrame) {
        this.topFrame = topFrame;
        initUI();
    }

    private void initUI() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel usernameLabel = new JLabel("Username:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(usernameLabel, gbc);

        usernameField = new JTextField(15);
        gbc.gridx = 1;
        gbc.gridy = 0;
        add(usernameField, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(passwordLabel, gbc);

        passwordField = new JPasswordField(15);
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(passwordField, gbc);

        loginButton = new JButton("Login");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(loginButton, gbc);

        signupButton = new JButton("Sign Up");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        add(signupButton, gbc);

        deleteAccountButton = new JButton("Delete Account");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        add(deleteAccountButton, gbc);

        messageLabel = new JLabel();
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        add(messageLabel, gbc);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loginUser();
            }
        });

        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                signupUser();
            }
        });

        deleteAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteAccount();
            }
        });
    }

    private void loginUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        try {
            URL url = new URL("http://127.0.0.1:3000/login");  // Adjust URL and port as necessary
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
    
            String jsonInputString = "{\"username\": \"" + username + "\", \"password\": \"" + password + "\"}";
    
            try (OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream())) {
                writer.write(jsonInputString);
                writer.flush();
            }
    
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
    
                if (response.toString().contains("\"success\":true")) {
                    JOptionPane.showMessageDialog(this, "Login Successful");
                    topFrame.remove(this);
                    topFrame.add(new GamePanel(username));
                    topFrame.revalidate();
                    topFrame.repaint();
                } else {
                    messageLabel.setText("Login failed. Please try again.");
                }
            } else if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
                messageLabel.setText("User not found.");
            } else if (responseCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
                messageLabel.setText("Invalid username or password.");
            } else {
                messageLabel.setText("Server returned error: " + responseCode);
            }
    
        } catch (Exception ex) {
            ex.printStackTrace();
            messageLabel.setText("Error connecting to server.");
        }
    }

    private void signupUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        try {
            URL url = new URL("http://127.0.0.1:3000/signup");  // Adjust URL and port as necessary
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
    
            String jsonInputString = "{\"username\": \"" + username + "\", \"password\": \"" + password + "\"}";
    
            try (OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream())) {
                writer.write(jsonInputString);
                writer.flush();
            }
    
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
    
                if (response.toString().contains("\"success\":true")) {
                    messageLabel.setText("Sign up successful. Please log in.");
                } else {
                    messageLabel.setText("Sign up failed. Username may already exist.");
                }
            } else if (responseCode == HttpURLConnection.HTTP_CONFLICT) {
                messageLabel.setText("Sign up failed. Username may already exist.");
            } else {
                messageLabel.setText("Server returned error: " + responseCode);
            }
    
        } catch (Exception ex) {
            ex.printStackTrace();
            messageLabel.setText("Error connecting to server.");
        }
    }

    private void deleteAccount() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
    
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete your account?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
    
        try {
            URL url = new URL("http://127.0.0.1:3000/delete_account");  // Adjust URL and port as necessary
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
    
            String jsonInputString = "{\"username\": \"" + username + "\", \"password\": \"" + password + "\"}";
    
            try (OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream())) {
                writer.write(jsonInputString);
                writer.flush();
            }
    
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
    
                if (response.toString().contains("\"success\":true")) {
                    messageLabel.setText("Account deleted successfully.");
                } else {
                    messageLabel.setText("Account deletion failed. Please try again.");
                }
            } else if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
                messageLabel.setText("Account deletion failed. Please try again.");
            } else {
                messageLabel.setText("Server returned error: " + responseCode);
            }
    
        } catch (Exception ex) {
            ex.printStackTrace();
            messageLabel.setText("Error connecting to server.");
        }
    }
}
